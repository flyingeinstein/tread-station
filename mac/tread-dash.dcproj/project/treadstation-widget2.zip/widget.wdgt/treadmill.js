
var spark;
var treadmill;

var baseURL = "https://api.spark.io/v1/devices/";
var MayaSpark = "48ff73065067555026182287";
var TreadmillSpark = "53ff67065067544838101187";


function zeropad(number) {
    return (number<10) ? '0'+number : number;
}

function clamp(value, minV, maxV)
{
    value = Number(value);
    if(value < minV)
        return minV;
    else if(value > maxV)
        return maxV;
    else
        return value;
}

function Treadmill()
{
    // variables
	this.runningTime = 0;       // total running millis (accumulates start/stops until a reset)
    this.runningSince = null;   // Date that we started running (non stop)
	this.speed = 0;
    
    // settings
    this.speedIncrement = 0.1;
    this.minSpeed = 2.5;
    this.maxSpeed = 8;
    this.incline = 0;
    this.inclineIncrement = 1;
    this.minIncline = 0;
    this.maxIncline = 50;
    
    // internals
    this.__timeUpdateInterval = null;
}

function ws_status(str)
{

}

Treadmill.prototype.connection = function(url)
{
}


Treadmill.prototype.MPHtoNative = function(value) 
{
    // 90 is 2mph, 150 is 3.4mph, 250 is 6mph
    return Number(value) * 45;
}

Treadmill.prototype.nativeToMPH = function(value) 
{
    return Number(value) / 45;
}

Treadmill.prototype.inclineGradetoNative = function(value) 
{
    // 90 is 2mph, 150 is 3.4mph, 250 is 6mph
    return Number(value);
}

Treadmill.prototype.nativeToInclineGrade = function(value) 
{
    return Number(value);
}


Treadmill.prototype.setSpeed = function(value, onSuccess, onFailure) 
{
    if(value==0 || value=="STOP" || value=="ESTOP" ) {
        value = 0;
    } else
        value = clamp(Number(value), this.minSpeed, this.maxSpeed);
    
    // accept the speed
    this.speed = value;
    
    // if we are starting or stopping, then start our running timer
    if(this.speed==0 && this.__timeUpdateInterval!=null) {
        // we are stopping
        clearInterval(this.__timeUpdateInterval);
        this.__timeUpdateInterval = null;
        
        if(this.runningSince!=null) {
            this.runningTime += new Date().valueOf() - this.runningSince.valueOf();
            this.runningSince = null;
        }
    } else if(this.__timeUpdateInterval==null) {
        // we are starting
        this.runningSince = new Date();
        var t = this;
        this.__timeUpdateInterval = setInterval(function() { t.__doUpdateRunningTime(); }, 1000);
    }
    
    // send notifications or callbacks
    if(onSuccess)
        onSuccess(value);
    if(this.onSpeedChanged)
        this.onSpeedChanged(value);
}

Treadmill.prototype.setIncline = function(value, onSuccess, onFailure) 
{
    value = clamp(Number(value), this.minIncline, this.maxIncline);
    this.incline = value;
    if(onSuccess)
        onSuccess(value);
    if(this.onInclineChanged)
        this.onInclineChanged(value);
}

Treadmill.prototype.increaseSpeed = function(onSuccess, onFailure) 
{
    return this.setSpeed(this.speed + this.speedIncrement);
}

Treadmill.prototype.decreaseSpeed = function(onSuccess, onFailure) 
{
    return this.setSpeed(this.speed - this.speedIncrement);
}

Treadmill.prototype.stop = function(onSuccess, onFailure) 
{
    return this.setSpeed("STOP");
}

Treadmill.prototype.estop = function(onSuccess, onFailure) 
{
    return this.setSpeed("ESTOP");
}

Treadmill.prototype.inclineUp = function(onSuccess, onFailure) 
{
    return this.setIncline(this.incline + this.inclineIncrement);
}

Treadmill.prototype.inclineDown = function(onSuccess, onFailure) 
{
    return this.setIncline(this.incline - this.inclineIncrement);
}

Treadmill.prototype.floor = function(onSuccess, onFailure) 
{
    return this.setIncline(this.minIncline);
}

Treadmill.prototype.getTotalRunningMillis = function()
{
    return (this.runningSince==null)
        ? this.runningTime
        : this.runningTime + (new Date().valueOf() - this.runningSince.valueOf());
}

Treadmill.prototype.__doUpdateRunningTime = function()
{
    var seconds, minutes, hours;
    if(this.onUpdateRunningTime) {
        seconds = Math.floor(this.getTotalRunningMillis() / 1000);
        minutes = Math.floor((seconds / 60)) % 60;
        hours = Math.floor(seconds / 3600);
        seconds = seconds % 60;
        this.onUpdateRunningTime(seconds, minutes, hours);
    }
}

$(function() 
{
	treadmill = new Treadmill();	

	/*setInterval(function() {
		var speed_desired = $("#speed .set-value").text();
		var speed_actual = $("#speed .set-value").text();
		
	}, 2000);*/
});